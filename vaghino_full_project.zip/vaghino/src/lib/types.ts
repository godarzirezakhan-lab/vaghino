export type Book = {
  id: string; title: string; subtitle: string | null; description: string;
  author_id: string; author_name?: string; category: string; cover_url: string | null;
  content: string | null; file_url: string | null; price: number; is_free: boolean;
  status: 'draft' | 'pending' | 'published' | 'rejected'; created_at: string;
};
export const categories = ['همه','جنایی','عاشقانه','ترسناک','تاریخی','فانتزی','علمی‌تخیلی','آموزشی','کودک و نوجوان','زندگی‌نامه'];
